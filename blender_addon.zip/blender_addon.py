bl_info = {
    "name": "Shape Grammar Config",
    "blender": (3, 0, 0),
    "category": "Object",
}

import bpy


def draw_axis(col, property, name):
    """Aux func to draw axis buttons"""
    col.label(text=name)
    row = col.row(align=True)
    row.prop(property, "x")
    row.prop(property, "y")
    row.prop(property, "z")

class AxisPropertiesOff(bpy.types.PropertyGroup):
    x: bpy.props.BoolProperty(name="X", default=False)
    y: bpy.props.BoolProperty(name="Y", default=False)
    z: bpy.props.BoolProperty(name="Z", default=False)

class AxisPropertiesOn(bpy.types.PropertyGroup):
    x: bpy.props.BoolProperty(name="X", default=True)
    y: bpy.props.BoolProperty(name="Y", default=True)
    z: bpy.props.BoolProperty(name="Z", default=True)


# Rules
class OBJECT_UL_rules(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            layout.prop(item, "name", text="", emboss=True)

class RuleItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Rule")  # user text input

# --- Operators for add/remove ---
class OBJECT_OT_rule_add(bpy.types.Operator):
    bl_idname = "object.rule_add"
    bl_label = "Add Rule"

    def execute(self, context):
        obj = context.object
        obj.rules.add()
        obj.rules_index = len(obj.rules) - 1
        return {'FINISHED'}

class OBJECT_OT_rule_remove(bpy.types.Operator):
    bl_idname = "object.rule_remove"
    bl_label = "Remove Rule"

    def execute(self, context):
        obj = context.object
        if obj.rules:
            obj.rules.remove(obj.rules_index)
            obj.rules_index = max(0, obj.rules_index - 1)
        return {'FINISHED'}


# --------------------
# Global Scene Properties
# --------------------

class RMGlobalProperties(bpy.types.PropertyGroup):
    description: bpy.props.StringProperty(
        name="Description",
        default="Archivo de ejemplo de configuración con los principales elementos"
    )
    samples: bpy.props.IntProperty(name="Samples", default=10, min=1)

    # Output
    output_blendfile: bpy.props.BoolProperty(name="Blendfile", default=False)
    output_values: bpy.props.BoolProperty(name="Values", default=True)
    output_stl: bpy.props.BoolProperty(name="STL", default=True)
    output_render: bpy.props.BoolProperty(name="Render", default=True)
    output_mosaic: bpy.props.BoolProperty(name="Mosaic", default=True)

    # Render config
    render_scene: bpy.props.EnumProperty(
        name="Render Scene",
        items=[
            ('one_light', "One Light", ""),
            ('basic', "Basic", ""),
            ('empty', "Empty", ""),
            ('neon', "Neon", ""),
            ('one_light-top', "One Light Top", "")
        ],
        default='one_light'
    )
    render_material: bpy.props.EnumProperty(
        name="Material",
        items=[
            ('clay', "Clay", ""),
            ('clay_red', "Clay Red", ""),
            ('wood_bamboo', "Wood Bamboo", "")
        ],
        default='clay'
    )
    render_quality: bpy.props.IntProperty(name="Quality", default=50, min=1, max=100)
    render_res_x: bpy.props.IntProperty(name="Res X", default=400, min=64, max=8192)
    render_res_y: bpy.props.IntProperty(name="Res Y", default=400, min=64, max=8192)


# --------------------
# Per-Object Properties
# --------------------

class RMDetailProperties(bpy.types.PropertyGroup):
    number_transf: bpy.props.IntProperty(name="Number of Transformations", default=2, min=0)
    max_number_forms: bpy.props.IntProperty(name="Max Number of Forms", default=2, min=1)
    optional: bpy.props.BoolProperty(name="Optional", default=False)
    # keep_shape: bpy.props.BoolProperty(name="Keep Shape", default=False)
    ignore: bpy.props.BoolProperty(name="Ignore", default=False)

    # Forms
    cube: bpy.props.BoolProperty(name="Cube", default=True)
    cylinder: bpy.props.BoolProperty(name="Cylinder", default=False)

    cube_loft: bpy.props.BoolProperty(name="Cube loft", default=False)
    cube_loft_max_displacement : bpy.props.FloatProperty(name="Max Displacement", default=0.9, min=0.0, max=1.0)
    cube_loft_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)
    cube_loft_shape: bpy.props.EnumProperty(
        name="Shape",
        items=[('concave', "concave", ""), ('convex', "convex", ""), ('random', "random", "")],
        default='random'
    )

    quadrilateral: bpy.props.BoolProperty(name="Quadrilateral", default=False)
    quadrilateral_fixed_axis: bpy.props.PointerProperty(type=AxisPropertiesOff)
    quadrilateral_max_displacement : bpy.props.FloatProperty(name="Max Displacement", default=0.9, min=0.0, max=1.0)

    dome_cut: bpy.props.BoolProperty(name="Dome cut", default=False)

    revolution: bpy.props.BoolProperty(name="Revolution", default=False)
    revolution_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)

    sphere: bpy.props.BoolProperty(name="Sphere", default=False)
    torus: bpy.props.BoolProperty(name="Torus", default=False)
    cone: bpy.props.BoolProperty(name="Cone", default=False)
    tube_square: bpy.props.BoolProperty(name="Tube square", default=False)

    swept: bpy.props.BoolProperty(name="Swept", default=False)
    swept_depth_factor : bpy.props.FloatProperty(name="Depth Factor", default=0.9, min=0.0, max=1.0)
    swept_extrude_factor : bpy.props.FloatProperty(name="Extrude Factor", default=0.9, min=0.0, max=1.0)
    swept_max_displacement : bpy.props.FloatProperty(name="Max Displacement", default=0.9, min=0.0, max=1.0)
    swept_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)

    
    polygon: bpy.props.BoolProperty(name="Polygon", default=False)
    polygon_max_vertice : bpy.props.IntProperty(name="Max Vertices", default=32, min=3, max=50)


    # Transformations

    shade: bpy.props.BoolProperty(name="Shade", default=False)
    shade_shade_type: bpy.props.EnumProperty(
        name="Type",
        items=[('smooth', "smooth", ""), ('flat', "flat", ""), ('random', "random", "")],
        default='random'
    )

    twist: bpy.props.BoolProperty(name="Twist", default=False)
    twist_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)
    twist_max_twist: bpy.props.FloatProperty(name="Max Twist", default=0.8, min=0.0, max=1.0)

    taper: bpy.props.BoolProperty(name="Taper", default=False)
    taper_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)

    bend: bpy.props.BoolProperty(name="Bend", default=False)
    bend_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)

    bevel: bpy.props.BoolProperty(name="Bevel", default=False)
    bevel_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)
    bevel_max_segments : bpy.props.IntProperty(name="Max Segments", default=5, min=1, max=10)

    scale: bpy.props.BoolProperty(name="Scale", default=False)
    scale_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)
    scale_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)

    rotation: bpy.props.BoolProperty(name="Rotation", default=False)
    rotation_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)
    rotation_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)

    mirror: bpy.props.BoolProperty(name="Mirror", default=False)
    mirror_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)

    array_rotation: bpy.props.BoolProperty(name="Array Rotation", default=False)
    array_rotation_max_count : bpy.props.IntProperty(name="Max Count", default=8, min=1, max=30)


    array: bpy.props.BoolProperty(name="Array", default=False)
    array_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)
    array_relative_offset_displace : bpy.props.FloatProperty(name="Offset", default=1.1, min=0.0, max=2.0)
    array_max_count : bpy.props.IntProperty(name="Max Count", default=8, min=1, max=30)
    array_scale_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)

    expand: bpy.props.BoolProperty(name="Expand", default=False)
    expand_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)

    contract: bpy.props.BoolProperty(name="Contract", default=False)
    contract_axis: bpy.props.PointerProperty(type=AxisPropertiesOn)


    pull: bpy.props.BoolProperty(name="Pull", default=False) 
    pull_factor : bpy.props.FloatProperty(name="Factor", default=0.9, min=0.0, max=1.0)
    pull_direction: bpy.props.EnumProperty(
        name="Type",
        items=[('down', "down", ""), ('up', "up", ""), ('random', "random", "")],
        default='random'
    )



    texture: bpy.props.BoolProperty(name="Texture", default=False)
    texture_strength_factor: bpy.props.FloatProperty(name="Strength", default=0.8, min=0.1, max=1.0)
    texture_scale_factor: bpy.props.FloatProperty(name="Scale", default=0.8, min=0.1, max=1.0)
    texture_location_factor: bpy.props.FloatProperty(name="Location", default=0.8, min=0.1, max=1.0)



# --------------------
# UI Panels
# --------------------
class VIEW3D_PT_rm_global(bpy.types.Panel):
    bl_label = "Shape Grammar Config"
    bl_idname = "VIEW3D_PT_rm_global"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ShapeGrammar"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        props = context.scene.rm_global

        layout.prop(props, "description")
        layout.prop(props, "samples")

        box = layout.box()
        box.label(text="Output")
        col = box.column(align=True)
        col.prop(props, "output_blendfile")
        col.prop(props, "output_values")
        col.prop(props, "output_stl")
        col.prop(props, "output_render")
        col.prop(props, "output_mosaic")

        box = layout.box()
        box.label(text="Render Config")
        col = box.column(align=True)
        col.prop(props, "render_scene")
        col.prop(props, "render_material")
        col.prop(props, "render_quality")
        col.prop(props, "render_res_x")
        col.prop(props, "render_res_y")


class OBJECT_PT_rm_detail(bpy.types.Panel):
    bl_label = "Shape Grammar"
    bl_idname = "OBJECT_PT_rm_detail"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.type == 'MESH'

    def draw(self, context):
        obj = context.object
        if not obj:
            return
        props = obj.rm_detail
        layout = self.layout

        layout.label(text="General Settings")
        layout.prop(props, "number_transf")
        layout.prop(props, "max_number_forms")
        layout.prop(props, "optional")
        # layout.prop(props, "keep_shape")
        layout.prop(props, "ignore")

        box = layout.box()
        box.label(text="Forms")
        col = box.column()
        col.prop(props, "cube")
        col.prop(props, "cylinder")
        col.prop(props, "cube_loft")
        if props.cube_loft:
            col.prop(props, 'cube_loft_shape')
            col.prop(props, 'cube_loft_max_displacement')
            col.prop(props, 'cube_loft_factor')
            col.separator()

        col.prop(props, "dome_cut")
        col.prop(props, "quadrilateral")
        if props.quadrilateral:
            draw_axis(col, props.quadrilateral_fixed_axis, "Fixed Axes:")
            col.prop(props, 'quadrilateral_max_displacement')
            col.separator()

        col.prop(props, "revolution")
        if props.revolution:
            col.prop(props, 'revolution_factor')
            col.separator()

        col.prop(props, "polygon")
        if props.polygon:
            col.prop(props, 'polygon_max_vertice')
            col.separator()


        col.prop(props, "cone")
        col.prop(props, "sphere")
        col.prop(props, "torus")
        col.prop(props, "tube_square")
        col.prop(props, "swept")
        if props.swept:
            draw_axis(col, props.swept_axis, "Axes:")
            col.prop(props, 'swept_depth_factor')
            col.prop(props, 'swept_extrude_factor')
            col.prop(props, 'swept_max_displacement')
            col.separator()

        #### TRANSFORMATIONS

        box = layout.box()
        box.label(text="Transformations")
        col = box.column(align=True)

        col.prop(props, "shade")
        if props.shade:
            col.prop(props, "shade_shade_type")
            col.separator()

        col.prop(props, "twist")
        if props.twist:
            draw_axis(col, props.twist_axis, "Axes:")
            col.prop(props, "twist_max_twist")
            col.separator()

        col.prop(props, "taper")
        if props.taper:
            draw_axis(col, props.taper_axis, "Axes:")
            col.separator()
        
        col.prop(props, "bend")
        if props.bend:
            draw_axis(col, props.bend_axis, "Axes:")
            col.separator()

        col.prop(props, "bevel")
        if props.bevel:
            col.prop(props, "bevel_factor")
            col.prop(props, "bevel_max_segments")
            col.separator()

        col.prop(props, "scale")
        if props.scale:
            draw_axis(col, props.scale_axis, "Axes:")
            col.prop(props, "scale_factor")
            col.separator()

        col.prop(props, "rotation")
        if props.rotation:
            draw_axis(col, props.rotation_axis, "Axes:")
            col.prop(props, "rotation_factor")
            col.separator()

        col.prop(props, "mirror")
        if props.mirror:
            draw_axis(col, props.mirror_axis, "Axes:")
            col.separator()

        col.prop(props, "array_rotation")
        if props.array_rotation:
            col.prop(props, "array_rotation_max_count")
            col.separator()

        col.prop(props, "array")
        if props.array:
            draw_axis(col, props.array_axis, "Axes:")
            col.prop(props, "array_relative_offset_displace")
            col.prop(props, "array_max_count")
            col.prop(props, "array_scale_factor")
            col.separator()


        col.prop(props, "expand")
        if props.expand:
            draw_axis(col, props.expand_axis, "Axes:")
            col.separator()

        col.prop(props, "contract")
        if props.contract:
            draw_axis(col, props.contract_axis, "Axes:")
            col.separator()

        col.prop(props, "pull")
        if props.pull:
            col.prop(props, "pull_direction")
            col.prop(props, "pull_factor")
            col.separator()


        col.prop(props, "texture")
        if props.texture:
            col.prop(props, "texture_strength_factor")
            col.prop(props, "texture_location_factor")
            col.prop(props, "texture_scale_factor")
            col.separator()

        # RULES
        box = layout.box()
        box.label(text="Rules")
        col = box.column(align=True)
        row = box.row()

        row.template_list("OBJECT_UL_rules", "", obj, "rules", obj, "rules_index")

        col = row.column(align=True)
        col.operator("object.rule_add", icon="ADD", text="")
        col.operator("object.rule_remove", icon="REMOVE", text="")



# --------------------
# Registration
# --------------------
classes = [OBJECT_OT_rule_remove, OBJECT_OT_rule_add, RuleItem, OBJECT_UL_rules, AxisPropertiesOff, AxisPropertiesOn, RMGlobalProperties, RMDetailProperties,
           VIEW3D_PT_rm_global, OBJECT_PT_rm_detail]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.rm_global = bpy.props.PointerProperty(type=RMGlobalProperties)
    bpy.types.Object.rm_detail = bpy.props.PointerProperty(type=RMDetailProperties)
    bpy.types.Object.rules = bpy.props.CollectionProperty(type=RuleItem)
    bpy.types.Object.rules_index = bpy.props.IntProperty()

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.rm_global
    del bpy.types.Object.rm_detail

if __name__ == "__main__":
    register()
